javac -d bin/ --module-path /usr/share/openjfx/lib/ --add-modules javafx.controls,javafx.media src/*.java
java -cp bin --module-path /usr/path/openjfx/lib/ --add-modules javafx.controls,javafx.media Executable
